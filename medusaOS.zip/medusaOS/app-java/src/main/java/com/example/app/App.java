package com.example.app;

import com.example.core.Utils;

public class App {
    public static void main(String[] args) {
        System.out.println(Utils.greeting());
    }
}