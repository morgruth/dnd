##E:\javascript\medusaOS
#tools for a network and front end application on the pc only
#configure PATH:\$ should be under init.conf
#WORKSPACE = r"F:\python projects\javascript"
#MEDUSA_OS = os.path.join(WORKSPACE, "medusaOS")

#JAVA_BIN = r"F:\python projects\javascript\jdk-25_windows-x64_bin\jdk-25.0.1\bin"
#GRADLE_BIN = r"F:\python projects\javascript\gradle-9.1.0-bin\gradle-9.1.0\bin"
#use fs as a linux file structure
#What this does in your workspace:
#home/user/: Contains your target simulated user workspace, featuring folders like Desktop and hidden asset configurations (.config).
#usr/share/: The standard repository path where a Linux environment looks for external desktop configuration profiles, 
#menu shortcuts (.desktop files), and default system wallpapers.
#etc/: Ready to host global text configurations for your OS engine
'''
E:\javascript\medusaOS\
├── fs/                         # Your simulated Linux file system
└── src/                        # Your Desktop Environment source code
    ├── index.html              # The main screen wrapper
    ├── styles/
    │   └── desktop.css         # Core layout, window management, and themes
    └── js/
        ├── main.js             # Initializes the system
        ├── wm.js               # Window Manager (open, close, drag windows)
        └── vfs.js              # Virtual File System bridge (reads from your /fs folder)
'''
@linux_desktop_fs.py