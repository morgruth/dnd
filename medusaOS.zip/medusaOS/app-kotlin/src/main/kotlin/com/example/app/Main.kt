package com.example.app

import com.example.core.Utils

fun main() {
    println(Utils.greeting())
}