package com.example.core

object Utils {
    @JvmStatic
    fun greeting(): String {
        return "Hello from Core Kotlin module!"
    }
}