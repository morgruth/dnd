import os
import sys
import subprocess
import winreg

def add_to_windows_path(target_path):
    print(f"[*] Registering directory path to Windows Environment...")
    try:
        # Access the user environment registry key
        key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Environment", 0, winreg.KEY_ALL_ACCESS)
        
        # Pull the existing Path string
        try:
            existing_path, data_type = winreg.QueryValueEx(key, "Path")
        except FileNotFoundError:
            existing_path = ""
            data_type = winreg.REG_EXPAND_SZ

        # Append path only if it doesn't already exist in the list
        if target_path.lower() not in existing_path.lower():
            new_path = f"{existing_path};{target_path}" if existing_path else target_path
            winreg.SetValueEx(key, "Path", 0, data_type, new_path)
            print(f"[+] Successfully added to Windows Environment Path: {target_path}")
            
            # Broadcast the environment update system-wide
            import ctypes
            HWND_BROADCAST = 0xFFFF
            WM_SETTINGCHANGE = 0x001A
            ctypes.windll.user32.SendMessageW(HWND_BROADCAST, WM_SETTINGCHANGE, 0, "Environment")
        else:
            print("[!] This path is already present in your Windows environment settings.")
            
        winreg.CloseKey(key)
    except PermissionError:
        print("[X] ERROR: Access Denied. Please run this Python script as an Administrator.")
    except Exception as e:
        print(f"[X] An error occurred setting up path routing: {e}")

def create_workspace():
    project_dir = r"E:\python-projects\javascript\medusaOS"
    print(f"[*] Initializing multi-project layout in: {project_dir}")
    
    # 1. Establish the clean multi-project directory layout
    dirs = [
        "core/src/main/kotlin/com/example",
        "app-java/src/main/java/com/example",
        "app-kotlin/src/main/kotlin/com/example"
    ]
    for d in dirs:
        os.makedirs(os.path.join(project_dir, d), exist_ok=True)
        print(f"[+] Subproject directory initialized: {d}")
        
    # 2. Inject root configuration files
    root_build_gradle = '''plugins {
    id "org.jetbrains.kotlin.jvm" version "2.4.0" apply(false)
}
'''
    with open(os.path.join(project_dir, "build.gradle"), "w", encoding="utf-8") as f:
        f.write(root_build_gradle)
    print("[+] Generated root file: build.gradle")

    root_settings_gradle = '''rootProject.name = "medusaOS"

include("core", "app-java", "app-kotlin")
'''
    with open(os.path.join(project_dir, "settings.gradle"), "w", encoding="utf-8") as f:
        f.write(root_settings_gradle)
    print("[+] Generated root file: settings.gradle")

    # 3. Inject subproject build profiles
    core_build_gradle = '''plugins {
    id "org.jetbrains.kotlin.jvm"
}

repositories {
    mavenCentral()
}
'''
    with open(os.path.join(project_dir, "core", "build.gradle"), "w", encoding="utf-8") as f:
        f.write(core_build_gradle)
    print("[+] Generated subproject profile: core/build.gradle")

    app_java_build_gradle = '''plugins {
    id "application"
}

repositories {
    mavenCentral()
}

dependencies {
    implementation project(":core")
}

java {
    toolchain {
        languageVersion = JavaLanguageVersion.of(25)
    }
}

application {
    mainClass = 'com.example.App'
}
'''
    with open(os.path.join(project_dir, "app-java", "build.gradle"), "w", encoding="utf-8") as f:
        f.write(app_java_build_gradle)
    print("[+] Generated subproject profile: app-java/build.gradle")

    app_kotlin_build_gradle = '''plugins {
    id "application"
    id "org.jetbrains.kotlin.jvm"
}

repositories {
    mavenCentral()
}

dependencies {
    implementation project(":core")
}

application {
    mainClass = 'com.example.KotlinAppKt'
}
'''
    with open(os.path.join(project_dir, "app-kotlin", "build.gradle"), "w", encoding="utf-8") as f:
        f.write(app_kotlin_build_gradle)
    print("[+] Generated subproject profile: app-kotlin/build.gradle")

    # 4. Inject application source assets
    utils_kt_content = '''package com.example

object Utils {
    fun getGreeting(): String {
        return "Hello from Kotlin 2.4.0!"
    }
}
'''
    with open(os.path.join(project_dir, "core/src/main/kotlin/com/example/Utils.kt"), "w", encoding="utf-8") as f:
        f.write(utils_kt_content)
    print("[+] Generated shared asset: core/.../Utils.kt")

    app_java_content = '''package com.example;

public class App {
    public static void main(String[] args) {
        System.out.println(Utils.INSTANCE.getGreeting());
        System.out.println("Running natively on Windows with JDK 25!");
    }
}
'''
    with open(os.path.join(project_dir, "app-java/src/main/java/com/example/App.java"), "w", encoding="utf-8") as f:
        f.write(app_java_content)
    print("[+] Generated Java asset: app-java/.../App.java")

    app_kotlin_content = '''package com.example

fun main() {
    println(Utils.getGreeting())
    println("Running natively on Windows with Kotlin and JDK 25!")
}
'''
    with open(os.path.join(project_dir, "app-kotlin/src/main/kotlin/com/example/KotlinApp.kt"), "w", encoding="utf-8") as f:
        f.write(app_kotlin_content)
    print("[+] Generated Kotlin asset: app-kotlin/.../KotlinApp.kt")

    # Register environment routing path
    add_to_windows_path(project_dir)

    # Automated wrapper generation
    print("[*] Generating specialized local Gradle 9.1.0 build wrapper binaries...")
    try:
        os.chdir(project_dir)
        subprocess.run(["gradle", "wrapper", "--gradle-version", "9.1.0"], shell=True, check=True)
        print("[+] Gradle configuration successfully wrappered locally!")
        print(f"\n[SUCCESS] Environment ready! Run options:\n -> gradle :app-java:run\n -> gradle :app-kotlin:run")
    except Exception:
        print("\n[WARNING] Script was unable to invoke a global 'gradle' toolchain path variable command.")
        print("To finish manually, navigate into your target directory and execute:")
        print("gradle wrapper --gradle-version 9.1.0")

if __name__ == "__main__":
    create_workspace()