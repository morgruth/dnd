import os
from pathlib import Path

def build_medusa_fs():
    # Your specified Windows target path
    target_base_path = r"E:\javascript\medusaOS\fs"
    
    # 1. Standard Linux core system directories
    system_dirs = [
        "boot", "dev", "etc", "lib", "media", "mnt", 
        "opt", "proc", "root", "run", "sbin", "srv", 
        "sys", "tmp", "var/log"
    ]
    
    # 2. Linux User space & Desktop Environment directories (XDG standards)
    user_desktop_dirs = [
        "home/user/Desktop",
        "home/user/Documents",
        "home/user/Downloads",
        "home/user/Music",
        "home/user/Pictures",
        "home/user/Videos",
        "home/user/.config",
        "home/user/.local/share"
    ]
    
    # 3. System desktop UI assets (shortcuts, themes, background wallpapers)
    desktop_asset_dirs = [
        "usr/bin",
        "usr/lib",
        "usr/local",
        "usr/share/applications",
        "usr/share/themes",
        "usr/share/icons",
        "usr/share/backgrounds"
    ]
    
    # Combine all structural directory definitions
    all_dirs = system_dirs + user_desktop_dirs + desktop_asset_dirs
    base_path = Path(target_base_path)

    print(f"Initializing MedusaOS file system layout inside:\n{base_path.resolve()}\n")

    for folder in all_dirs:
        # Safely joins paths regardless of OS (Windows '\' vs Linux '/')
        full_path = base_path / folder
        
        try:
            # parents=True creates missing mid-level folders; exist_ok=True avoids crashes if rerun
            full_path.mkdir(parents=True, exist_ok=True)
            print(f" [Created] \\{folder}")
        except Exception as e:
            print(f" [Error] Failed to create {folder}: {e}")

    print("\n[Success] Linux desktop file system architecture is ready for MedusaOS!")

if __name__ == "__main__":
    build_medusa_fs()