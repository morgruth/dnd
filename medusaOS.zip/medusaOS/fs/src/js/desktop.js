// 1. Live Clock Sync Engine
function updateClock() {
    const clockElement = document.getElementById('clock');
    if (clockElement) {
        const now = new Date();
        clockElement.innerText = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    }
}
setInterval(updateClock, 1000);
updateClock();

// Global Environment Paths for Simulated MedusaOS File System
let currentPath = "/home/user";
const mockFileSystem = {
    "/": ["boot", "dev", "etc", "home", "usr", "var"],
    "/home": ["user"],
    "/home/user": ["Desktop", "Documents", "Downloads", "Music", "Pictures", "Videos"],
    "/home/user/Desktop": ["medusa_wallpaper.jpg"],
    "/usr": ["bin", "lib", "local", "share"]
};

// 2. Window Generation Manager
const terminalShortcut = document.getElementById('term-shortcut');

if (terminalShortcut) {
    terminalShortcut.addEventListener('click', () => {
        const terminalHTML = `
            <div class="terminal-container">
                <div class="terminal-log">Welcome to MedusaOS v1.0.0\nType "help" for a list of commands.\n\n</div>
                <div class="terminal-prompt-line">
                    <span class="prompt-text">medusaOS@root:~#&nbsp;</span>
                    <input type="text" class="terminal-input" autofocus autocomplete="off" spellcheck="false">
                </div>
            </div>
        `;
        
        // Spawn the window
        const win = createWindow('Terminal', terminalHTML);
        
        // Direct Engine Hookup: Ensure the newly created input field responds directly to key events
        const currentInput = win.querySelector('.terminal-input');
        const logBox = win.querySelector('.terminal-log');
        
        if (currentInput) {
            // Force keyboard focus immediately onto the window prompt line
            currentInput.focus();

            // Autofocus window field back if user clicks elsewhere inside the layout window
            win.querySelector('.window-content').addEventListener('click', () => {
                currentInput.focus();
            });

            // Capture commands on Enter keypress execution
            currentInput.addEventListener('keydown', function(e) {
                if (e.key === 'Enter') {
                    const commandLine = this.value.trim();
                    
                    if (commandLine.length > 0) {
                        logBox.textContent += `medusaOS@root:~# ${commandLine}\n`;
                        
                        // Execute internal terminal router routing logic
                        executeCommand(commandLine, logBox);
                    } else {
                        logBox.textContent += `medusaOS@root:~# \n`;
                    }
                    
                    this.value = ''; // Reset core textbox
                    const contentBox = win.querySelector('.window-content');
                    contentBox.scrollTop = contentBox.scrollHeight; // Force scroll to bottom layout
                }
            });
        }
    });
}

function createWindow(title, contentMarkup) {
    const win = document.createElement('div');
    win.className = 'os-window';
    win.style.left = '150px';
    win.style.top = '120px';

    win.innerHTML = `
        <div class="window-header">
            <span>${title}</span>
            <button class="close-btn">×</button>
        </div>
        <div class="window-content">${contentMarkup}</div>
    `;

    document.getElementById('desktop').appendChild(win);

    win.querySelector('.close-btn').addEventListener('click', () => {
        win.remove();
    });

    setupDragAndDrop(win, win.querySelector('.window-header'));
    return win; // Return layout object instance reference for core listeners hookups
}

// 3. Simple Mock Shell Terminal Parser
function executeCommand(fullCommand, logElement) {
    const parts = fullCommand.split(' ');
    const command = parts[0].toLowerCase();
    const argument = parts[1];

    switch(command) {
        case 'help':
            logElement.textContent += `Available Commands:\n  ls      - List files in current folder\n  pwd     - Print working directory\n  cd      - Change path (e.g. cd /home)\n  clear   - Clear terminal display\n  whoami  - Show current login identity\n\n`;
            break;
            
        case 'pwd':
            logElement.textContent += `${currentPath}\n\n`;
            break;
            
        case 'whoami':
            logElement.textContent += `root\n\n`;
            break;
            
        case 'ls':
            const items = mockFileSystem[currentPath] || [];
            if (items.length > 0) {
                logElement.textContent += `${items.join('   ')}\n\n`;
            } else {
                logElement.textContent += `\n`;
            }
            break;
            
        case 'cd':
            if (!argument || argument === '~') {
                currentPath = "/home/user";
                logElement.textContent += `\n`;
            } else if (mockFileSystem[argument]) {
                currentPath = argument;
                logElement.textContent += `\n`;
            } else {
                logElement.textContent += `cd: no such file or directory: ${argument}\n\n`;
            }
            break;
            
        case 'clear':
            logElement.textContent = '';
            break;
            
        default:
            logElement.textContent += `medusaOS: command not found: ${command}\n\n`;
            break;
    }
}

// 4. Window Position Drag Management (Mouse Actions)
function setupDragAndDrop(windowEl, headerEl) {
    let diffX = 0, diffY = 0, initialX = 0, initialY = 0;

    headerEl.onmousedown = (e) => {
        e.preventDefault();
        initialX = e.clientX;
        initialY = e.clientY;

        document.onmouseup = () => {
            document.onmouseup = null;
            document.onmousemove = null;
        };

        document.onmousemove = (e) => {
            e.preventDefault();
            diffX = initialX - e.clientX;
            diffY = initialY - e.clientY;
            initialX = e.clientX;
            initialY = e.clientY;

            windowEl.style.top = (windowEl.offsetTop - diffY) + "px";
            windowEl.style.left = (windowEl.offsetLeft - diffX) + "px";
        };
    };
}