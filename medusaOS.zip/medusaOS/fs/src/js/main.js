function openWindow(title, content) {
    // Create the window wrapper container
    const win = document.createElement('div');
    win.className = 'window';
    win.style.left = '100px';
    win.style.top = '100px';

    // Create the Title Bar (for dragging/closing)
    const titleBar = document.createElement('div');
    titleBar.className = 'title-bar';
    titleBar.innerHTML = `<span>${title}</span><button class="close-btn">X</button>`;
    
    // Create the App Content Pane
    const body = document.createElement('div');
    body.className = 'window-body';
    body.innerHTML = content;

    win.appendChild(titleBar);
    win.appendChild(body);
    document.body.appendChild(win);

    // Close window event
    titleBar.querySelector('.close-btn').addEventListener('click', () => {
        win.remove();
    });

    // Make the window draggable
    makeDraggable(win, titleBar);
}

function makeDraggable(element, handle) {
    let posX = 0, posY = 0, mouseX = 0, mouseY = 0;
    handle.onmousedown = (e) => {
        e.preventDefault();
        mouseX = e.clientX;
        mouseY = e.clientY;
        document.onmouseup = () => {
            document.onmouseup = null;
            document.onmousemove = null;
        };
        document.onmousemove = (e) => {
            e.preventDefault();
            posX = mouseX - e.clientX;
            posY = mouseY - e.clientY;
            mouseX = e.clientX;
            mouseY = e.clientY;
            element.style.top = (element.offsetTop - posY) + "px";
            element.style.left = (element.offsetLeft - posX) + "px";
        };
    };
}
//terminal engine
// Simulated local state for our current directory path
window.currentPath = "/home/user";

// Mock file system representation for commands to interact with
window.mockFileSystem = {
    "/": ["boot", "dev", "etc", "home", "usr", "var"],
    "/home": ["user"],
    "/home/user": ["Desktop", "Documents", "Downloads", "Music", "Pictures", "Videos"],
    "/home/user/Desktop": ["medusa_wallpaper.jpg"],
    "/usr": ["bin", "lib", "local", "share"]
}

window.initTerminalEngine='',() => {
    // Find the newly spawned terminal input element
    const inputs = document.querySelectorAll('.terminal-input');
    const currentInput = inputs[inputs.length - 1]; // Target the latest window opened
    
    if (!currentInput) return;
    
    // Auto-focus input box when clicking inside the window content area
    currentInput.closest('.window-content').addEventListener('click', () => {
        currentInput.focus();
    });

    currentInput.addEventListener('keydown', function(e) {
        if (e.key === 'Enter') {
            const commandLine = this.value.trim();
            const log = this.closest('.terminal-container').querySelector('.terminal-log');
            
            if (commandLine.length > 0) {
                // Print what the user typed to the log history
                log.textContent += `medusaOS@root:~# ${commandLine}\n`;
                
                // Process the command string
                executeLinuxCommand(commandLine, log);
            } else {
                log.textContent += `medusaOS@root:~# \n`;
            }
            
            // Reset input box and scroll to bottom of the screen
            this.value = '';
            const contentBox = this.closest('.window-content');
            contentBox.scrollTop = contentBox.scrollHeight;
        }
    });
}

function executeLinuxCommand(fullCommand, logElement) {
    const parts = fullCommand.split(' ');
    const command = parts[0].toLowerCase();
    const argument = parts[1];

    switch(command) {
        case 'help':
            logElement.textContent += `Available Commands:\n  ls      - List files in current folder\n  pwd     - Print working directory\n  cd      - Change path (e.g. cd /home)\n  clear   - Clear terminal display\n  whoami  - Show current login identity\n\n`;
            break;
            
        case 'pwd':
            logElement.textContent += `${window.currentPath}\n\n`;
            break;
            
        case 'whoami':
            logElement.textContent += `root\n\n`;
            break;
            
        case 'ls':
            const items = window.mockFileSystem[window.currentPath] || [];
            if (items.length > 0) {
                logElement.textContent += `${items.join('   ')}\n\n`;
            } else {
                logElement.textContent += `\n`;
            }
            break;
            
        case 'cd':
            if (!argument || argument === '~') {
                window.currentPath = "/home/user";
                logElement.textContent += `\n`;
            } else if (window.mockFileSystem[argument]) {
                window.currentPath = argument;
                logElement.textContent += `\n`;
            } else {
                logElement.textContent += `cd: no such file or directory: ${argument}\n\n`;
            }
            break;
            
        case 'clear':
            logElement.textContent = '';
            break;
            
        default:
            logElement.textContent += `medusaOS: command not found: ${command}\n\n`;
            break;
    }
}